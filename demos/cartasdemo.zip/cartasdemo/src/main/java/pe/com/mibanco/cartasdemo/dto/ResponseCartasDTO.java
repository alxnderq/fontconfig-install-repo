package pe.com.mibanco.cartasdemo.dto;

import java.util.List;

import lombok.Data;

/**
 * ResponseCartasDTO
 */
@Data
public class ResponseCartasDTO {

    private List<String> cartas;

}