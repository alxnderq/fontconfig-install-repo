package pe.com.mibanco.cartasdemo.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.core.io.InputStreamResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import pe.com.mibanco.cartasdemo.dto.ResponseCartasDTO;
import pe.com.mibanco.cartasdemo.utils.ConvertPDFUtils;
import pe.com.mibanco.cartasdemo.utils.ExportFileUtils;

/**
 * CartasController
 */
@RestController
public class CartasController {

    @PostMapping(path = "/downloads", produces = MediaType.APPLICATION_PDF_VALUE)
    public ResponseEntity<InputStreamResource> download(@RequestBody ResponseCartasDTO dto) throws Exception {
        Date date = Calendar.getInstance().getTime();
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMddhhmmss");
        String filename = "Carta" + dateFormat.format(date) + ".pdf";
        String folder = "/tmp/templates/";
        List<String> paths = new ArrayList<>();
        dto.getCartas().forEach(carta -> {
            paths.add(folder + carta);
        });
        byte[] pdfAll = ConvertPDFUtils.convertPDF(paths);
        return ExportFileUtils.getFile(pdfAll, filename, MediaType.APPLICATION_PDF_VALUE);
    }

}