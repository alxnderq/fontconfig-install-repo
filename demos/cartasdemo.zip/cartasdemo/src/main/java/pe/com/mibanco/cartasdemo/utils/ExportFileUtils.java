package pe.com.mibanco.cartasdemo.utils;

import java.io.ByteArrayInputStream;

import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

/**
 * ExportFileUtils
 */
public class ExportFileUtils {

    private ExportFileUtils() {
        throw new IllegalStateException("Utility class");
    }

    public static ResponseEntity<InputStreamResource> getFile(byte[] archivoByte, String nombre, String contentType) {
        HttpHeaders headers = new HttpHeaders();
        headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
        headers.add("Pragma", "no-cache");
        headers.add("Expires", "0");
        headers.add(HttpHeaders.CONTENT_TYPE, contentType);
        headers.add(HttpHeaders.CONTENT_ENCODING, "UTF-8");
        headers.setContentDispositionFormData("attachment", nombre);

        ByteArrayInputStream byteArray = new ByteArrayInputStream(archivoByte);

        return ResponseEntity.ok().headers(headers)
                .contentType(MediaType.parseMediaType(MediaType.APPLICATION_OCTET_STREAM_VALUE))
                .body(new InputStreamResource(byteArray));
    }

}