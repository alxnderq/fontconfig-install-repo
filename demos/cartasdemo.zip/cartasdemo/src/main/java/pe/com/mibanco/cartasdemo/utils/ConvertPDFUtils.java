package pe.com.mibanco.cartasdemo.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfImportedPage;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfWriter;

import org.docx4j.Docx4J;
import org.docx4j.convert.out.FOSettings;

/**
 * ConvertPDFUtils
 */
public class ConvertPDFUtils {

    public static byte[] convertPDF(List<String> paths) throws Exception {
        List<ByteArrayInputStream> pdfBytes = new ArrayList<ByteArrayInputStream>();
        for (String path : paths) {
            WordUtils wordUtils = new WordUtils(path);
            wordUtils.getTemplate();
            FOSettings foSettings = Docx4J.createFOSettings();
            foSettings.setWmlPackage(wordUtils.getWordPackage());
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            Docx4J.toFO(foSettings, outputStream, Docx4J.FLAG_EXPORT_PREFER_XSL);
            pdfBytes.add(new ByteArrayInputStream(outputStream.toByteArray()));
        }
        return concatPDF(pdfBytes);
    }

    private static byte[] concatPDF(List<ByteArrayInputStream> pdfBytes) throws IOException, DocumentException {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        Document document = new Document();

        List<PdfReader> readers = new ArrayList<PdfReader>();

        for (InputStream pdf : pdfBytes) {
            PdfReader reader = new PdfReader(pdf);
            readers.add(reader);
        }

        PdfWriter writer = PdfWriter.getInstance(document, outputStream);

        document.open();

        PdfContentByte cb = writer.getDirectContent();

        PdfImportedPage page;
        int pageOfCurrentReaderPDF = 0;

        for (PdfReader pdfReader : readers) {
            while (pageOfCurrentReaderPDF < pdfReader.getNumberOfPages()) {
                document.newPage();
                pageOfCurrentReaderPDF++;
                page = writer.getImportedPage(pdfReader, pageOfCurrentReaderPDF);
                cb.addTemplate(page, 0, 0);
            }
            pageOfCurrentReaderPDF = 0;
        }
        document.close();
        return outputStream.toByteArray();
    }

}