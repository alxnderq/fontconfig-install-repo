package pe.com.mibanco.cartasdemo.utils;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;

import org.docx4j.Docx4J;
import org.docx4j.XmlUtils;
import org.docx4j.model.datastorage.migration.VariablePrepare;
import org.docx4j.openpackaging.exceptions.Docx4JException;
import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.docx4j.openpackaging.parts.WordprocessingML.MainDocumentPart;
import org.docx4j.wml.ContentAccessor;
import org.docx4j.wml.Tbl;
import org.docx4j.wml.Text;
import org.docx4j.wml.Tr;

/**
 * WordUtils
 */
public class WordUtils {

    private WordprocessingMLPackage wordPackage;
    private MainDocumentPart document;
    private String path;
    private InputStream input;
    private List<Object> objects;

    public WordUtils(String path) {
        super();
        this.path = path;
    }

    public void getTemplate() throws Exception {

        byte[] word = Files.readAllBytes(Paths.get(this.path));
        input = new ByteArrayInputStream(word);
        wordPackage = Docx4J.load(input);
        VariablePrepare.prepare(wordPackage);
        document = wordPackage.getMainDocumentPart();
    }

    public void replaceVariables(Map<String, String> map) throws JAXBException, Docx4JException {
        document.variableReplace((HashMap<String, String>) map);
    }

    public void getPlaceholder(Map<String, String> placeholders) {
        objects = getAllElements(document, Text.class);
        for (Map.Entry<String, String> map : placeholders.entrySet()) {
            replacePlaceholder(map.getKey(), map.getValue());
        }
    }

    public void replacePlaceholder(String placeholder, String textAdd) {
        for (Object text : objects) {
            Text textElement = (Text) text;
            if (textElement.getValue() != null && textElement.getValue().contains("${" + placeholder + "}")) {
                textElement.setValue(textAdd);
            }
        }
    }

    public void replaceTable(String[] placeholders, List<Map<String, String>> textAdd) {
        Integer rowInit = 2;
        replaceTable(placeholders, textAdd, rowInit);
    }

    public void replaceTable(String[] placeholders, List<Map<String, String>> textAdd, Integer rowInit) {
        objects = getAllElements(document, Tbl.class);
        Tbl templateTable = getTemplateTable(objects, placeholders[0]);
        if (templateTable != null) {
            List<Object> rows = getAllElements(templateTable, Tr.class);
            if (!rows.isEmpty() && rows.size() == rowInit) {
                Tr templateRow = (Tr) rows.get(rowInit - 1);
                for (Map<String, String> replace : textAdd) {
                    addRowToTable(templateTable, templateRow, replace);
                }
                templateTable.getContent().remove(templateRow);
            }
        }
    }

    public void save(OutputStream out) throws Docx4JException {
        wordPackage.save(out);
    }

    private List<Object> getAllElements(Object obj, Class<?> toSearch) {
        Object var = obj;
        List<Object> result = new ArrayList<>();
        if (obj instanceof JAXBElement) {
            var = ((JAXBElement<?>) obj).getValue();
        }
        if (var.getClass().equals(toSearch)) {
            result.add(var);
        } else if (var instanceof ContentAccessor) {
            List<?> children = ((ContentAccessor) var).getContent();
            for (Object child : children) {
                result.addAll(getAllElements(child, toSearch));
            }
        }
        return result;
    }

    private Tbl getTemplateTable(List<Object> tables, String templateKey) {
        for (Iterator<Object> iterator = tables.iterator(); iterator.hasNext();) {
            Object tbl = iterator.next();
            List<?> textElements = getAllElements(tbl, Text.class);
            for (Object text : textElements) {
                Text textElement = (Text) text;
                if (textElement.getValue() != null && textElement.getValue().equals(templateKey)) {
                    return (Tbl) tbl;
                }
            }
        }
        return null;
    }

    private void addRowToTable(Tbl reviewtable, Tr templateRow, Map<String, String> replacements) {
        Tr workingRow = XmlUtils.deepCopy(templateRow);
        List<?> textElements = getAllElements(workingRow, Text.class);
        for (Object object : textElements) {
            Text text = (Text) object;

            String replacementValue = replacements.get(text.getValue());
            if (replacementValue != null) {
                text.setValue(replacementValue);
            }

        }
        reviewtable.getContent().add(workingRow);
    }

    public WordprocessingMLPackage getWordPackage() {
        return wordPackage;
    }

    public void setWordPackage(WordprocessingMLPackage wordPackage) {
        this.wordPackage = wordPackage;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public InputStream getInput() {
        return input;
    }

    public void setInput(InputStream input) {
        this.input = input;
    }

    public MainDocumentPart getDocument() {
        return document;
    }

    public void setDocument(MainDocumentPart document) {
        this.document = document;
    }

}